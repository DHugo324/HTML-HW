// 引入套件
const express = require("express");
const router = express.Router();
const Todo = require("../models/todo");

// 取得全部資料
// 使用非同步，才能夠等待資料庫回應
router.get("/", async (req, res) => {
    // 使用try catch方便Debug的報錯訊息
    try {
        // 找出Todo資料資料表中的全部資料
        const todo = await Todo.find();
        // 將回傳的資訊轉成Json格式後回傳
        res.json(todo);
    } catch (err) {
        // 如果資料庫出現錯誤時回報 status:500 並回傳錯誤訊息 
        res.status(500).json({ message: err.message })
    }
});

// 新增待辦事項
// 將Method改為Post
router.post("/", async (req, res) => {
    // 從req.body中取出資料
    const todo = new Todo({
        thing: req.body.thing,
        isDone: req.body.isDone,
    });
    try {
        // 使用.save()將資料存進資料庫
        const newTodo = await todo.save();
        // 回傳status:201代表新增成功 並回傳新增的資料
        res.status(201).json(newTodo);
    } catch (err) {
        // 錯誤訊息發生回傳400 代表使用者傳入錯誤的資訊
        res.status(400).json({ message: err.message })
    }
});

// 檢視是否有指定ID之待辦事項(作為Middleware)
async function getTodo(req, res, next) {
    let todo;
    try {
        todo = await Todo.findById(req.params.id);
        if (todo == undefined) {
            return res.status(404).json({ message: "Can't find todo" })
        }
    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
    // 如果有該事項 則將他加入到res中
    res.todo = todo
    // 在router中執行middleware後需要使用next()才會繼續往下跑
    next();
}

// 檢視特定事項
// 在網址中傳入id用以查詢
// 會先執行getTodo後才繼續裡面的內容
router.get("/:id", getTodo, (req, res) => {
    // 取出res.todo並回傳
    res.send(res.todo);
});

// 刪除待辦事項
// 先使用getTodo取得該待辦資訊
router.delete("/:id", getTodo, async (req, res) => {
    try {
        // 將取出的待辦事項刪除
        await res.todo.remove();
        // 回傳訊息
        res.json({ message: "Delete todo succeed" })
    } catch (err) {
        // 資料庫操作錯誤將回傳500及錯誤訊息
        res.status(500).json({ message: "remove todo faild" })
    }
});

// Export 該Router
module.exports = router;