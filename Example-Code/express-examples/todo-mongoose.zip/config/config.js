// config.js
const config = {
    app: {
        port: 3000
    },
    db: {
        url: "mongodb://localhost/test"
    }
};

module.exports = config;