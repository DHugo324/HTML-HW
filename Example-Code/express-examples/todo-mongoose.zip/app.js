const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');

const express = require('express');
const mongoose = require("mongoose");
const app = express();

app.use(cookieParser());
app.use(logger('dev'));

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// 引入設定檔
const config = require("./config/config");

// 與資料庫連線
mongoose.connect(config.db.url);
const db = mongoose.connection;

// 與資料庫連線發生錯誤時
db.on('err', err => console.log(err));

// 與資料庫連線成功連線時
db.once('open', () => console.log('connected to database...'));

// 引入Router 一個Router基本上處理一個資料表
const todoRouter = require("./routes/todo");
// 此處的/todo代表連線到該Router的基本路徑為 http://localhost:3000/todo
app.use("/todo", todoRouter);

module.exports = app;